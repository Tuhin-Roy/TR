<html>
<head>
 <title> Client Home</title>
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<header>
   
   <center>
    <h1>welcome to ...... Airway's</h1>
	</center>
    
  </header><br>

<body>
<center>

    <nav>
      <input  type="search" placeholder="Search-Flight" />
      <button  type="submit">Search-Flight</button>
      <li><a href="profile.php">Profile</a></li>
	  <li><a href="popularflightoffer.php">Popular Flight Offer</a></li>
      <li><a href="about us.php">About Us</a></li>
      <li><a href="contact.php">Contact</a></li>
	  <br>
	  
	  </nav>
	  
	  
</center>
 <form>
 <center>
 <h4>...... Airway's</h4>
 
 <p> an air route, esp one that is fully equipped with emergency landing fields, navigational aids, etc. a passage for ventilation, esp in a mine. a passage down which air travels from the nose or mouth to the lungs.</P>
 </form>
 
<div class="card text-center">
 
  <div class="card-body">
    <p class="card-text">All Right Reserved By Tuhin Roy</p>
   
  </div>
  
</div>
</body>
</html>