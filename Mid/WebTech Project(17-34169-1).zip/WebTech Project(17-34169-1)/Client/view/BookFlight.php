	<?php

			echo "Name is: " . $_REQUEST["name"];	
            		
			echo"<br>";
			echo "Email id is: " . $_REQUEST["email"];
			echo"<br>";
			echo "Passport no is: " . $_REQUEST["passport"];
			
	?>
	<br>
	<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">