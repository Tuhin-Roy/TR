<!DOCTYPE HTML>
<html>
	<head>
		
		<title>Client Profile</title>
	</head>
	<body>
		<div>	
					
					
						
							
								<td><ul>
								<li><a href="editProfile.php"><h3>Edit Profile</h3></a></li>
								<li><a href="ChangePassword.php"><h3>Change Password</h3></a></li>

								<li><a href="../control/logout.php"><h3>Logout</h3></a></li>
							</ul>
						
						
							
										
										
										<center>
		
											<td>User Id:</td>
											<td><?php
												echo "17-34169-1"		
											     ?></td>
											<td></td>
											<td></td>
									<br><br>
										
											
										
										
											<td>Name:</td>
											<td><?php
											echo "Tuhin Roy";?></td>
											
											
										
									<br><br>
									
										
											<td>Email:</td>
											<td><?php echo "aiubtuhin@gmail.com";?></td>
											<td></td>
											<td></td>
									
										
											<br><br>
										
									
											<td>Gender:</td>
											<td><?php echo "Male"  ?></td>
											<td></td>
											<td></td>
									
									
											<br><br>
										
										
											<td>Address:</td>
											<td><?php echo "Khilkhet,Nikunjo-2";?></td>
											<td></td>
											<td></td>
										
									
											<br><br>
										
										
											<td>Registration Date:</td>
											<td><?php echo "2020-11-14";?></td>
											<td></td>
											<td></td>
										
										
											<br><br>
										
										
											<td>Blood Group:</td>
											<td><?php echo "0+";?></td>
											<td></td>
											<td></td>
										
										<br><br>
										
										
											<td>Phone:</td>
											<td><?php echo "01979019414";?></td>
											<td></td>
											<td></td>
										
											<br><br>
										
											<td>Date Of Birth:</td>
											<td><?php echo "11-11-1996";?></td>
											<td></td>
											<td></td>
										<br><br><br><br>
											<center>
											
																			
									
						
						</td>
					</tr>
					<div class="card text-center">
 
         <div class="card-body">
          <p class="card-text">All Right Reserved By Tuhin Roy</p>
   
          </div>
  
</div>
			</table>
			</div>
					
			
	</body>
</html>