<!DOCTYPE HTML>
<html>
	<head></head>
	<body>
	<form method="post" action="editflight.php">
	<h1>Flight Details</h1>
	
	
		<div>

					
				
						
									<center>
										<td> Flight Name:</td>
										<td></td>
										<td><input type ="text" name = "fname" method ="post"></td>
									
								
									<br><br>
									
										<td>Flight Id:</td>
										<td></td>
										<td><input type ="text" name = "fId" method ="post"></td>
								
									<br><br>
								
										<td> From:</td>
										<td></td>
										<td><input type ="text" name = "from" method ="post"></td>
									
								<br><br>
									
									
										<td> To:</td>
										<td></td>
										<td><input type ="text" name = "to" method ="post"></td>
									
									<br><br>
										<td>Seat Id:</td>
										<td></td>
										<td><input type ="text" name ="seatid" method ="post"></td>
									
									<br><br>
		
										<td> Flight Name:</td>
										<td></td>
										<td><input type ="text" name = "fname" method ="post"></td>
									
									<br><br>
										Seat type: <br/>
    <input type="radio" name="gender" value="Business class" required>Business class
    <br/>
	<input type="radio" name="gender" value="Economy class" required>Economy class
    <br/><br/>
										
										<br><br>
										
										<div>
 <label for="reedemcode">Choose a code:</label>

<select name="reedemcode" id="reedemcode">
  <option value="code Tu0010 for 30% Discount">Tu0010</option>
  <option value="code Su0010 for  25% Discount">Su0010</option>
  <option value="code Mu0010 for 20% Discount">Mu0010</option>
  <option value="code Ar0010 for 15% Discount">Ar0010</option>
</select>
</div> <br>
										
										<td><input type ="submit" value ="Confirm"></td>
										<td></td>
										<br><br><br><br>
									
							<center>
						
						
					
					
		
		</div>
		</table>
	</body>
</html>