	<?php

			echo " F Name is: " . $_REQUEST["fname"];	
            echo "<br>";
			echo " F Id is: " . $_REQUEST["fId"];		
			echo"<br>";
			echo "From: " . $_REQUEST["from"];
			echo"<br>";
			echo "To: " . $_REQUEST["to"];
			echo"<br>";
			echo " Seat Id is: " . $_REQUEST["seatid"];		
			echo"<br>";
			echo " Seat Type is: " . $_REQUEST["gender"];		
			echo"<br>";
			echo " Seat Code is: " . $_REQUEST["reedemcode"];		
			echo"<br>";

			
			
			
	?>
	<br>
	<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">