<!DOCTYPE HTML>
<htmlS>
	
	<body>
	<form method="post" action="editconfirm.php">
		<div>

					
				
						<td><ul>
								<li><a href="editProfile.php"><h3>Edit Profile</h3></a></li>
								<li><a href="ChangePassword.php"><h3>Change Password</h3></a></li>

								<li><a href="../control/logout.php"><h3>Logout</h3></a></li>
							</ul>
						</td>
						
							<center>
										<td>Name:</td>
										<td></td>
										<td><input type ="text" name = "mname" method ="post"></td>
									
									<br><br>
										<td>User Id:</td>
										<td></td>
										<td><input type ="text" name = "userId" method ="post"></td>
									
									<br><br>
										<td>Email:</td>
										<td></td>
										<td><input type ="email" name ="memail" method ="post"><button title ="hints:sample@com"><b>i</b></button></td>
									
									<br><br>
									
										<td><input type ="submit" value ="Submit"></td>
										<td></td>
										<td><input type ="reset"  value ="Reset"></td>
										<td></td>
									<br><br><br>
									
							<center>
						
						
					
					
		
		</div>
	</body>
</html>