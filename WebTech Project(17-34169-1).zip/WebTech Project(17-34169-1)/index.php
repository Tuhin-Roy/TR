<!DOCTYPE html>
<html>
<?php

  if (isset($_POST['registration']))
  {
    $Fname=$_POST["firstname"];
	$Lname=$_POST["lastname"];
    $Email=$_POST["email"];
	$Birth_Day=$_POST["b_date"];
	
    $password=$_POST["password"];
	
	$Cpassword=$_POST["confpassword"];
    $phone=$_POST["phone"];
	
    if(isset($_POST["gender"])){
    $role=$_POST["gender"];}
	
	
   
     if(!empty($Fname) && !empty($Lname) && !empty($email) && !empty($Birth_Day) && !empty($password) && !empty($Cpassword) && !empty($phone) &&!empty($role))
	 {
        
        $Success= 'Successfully Registerd';

      } else{

        $error='please fillup the required field';
    } 

  }



?>


  <head>
    <title>Registration</title>
  </head>
  <body>
  	<h1> Registration form! </h1>
	
	
    <form action="" method="POST">
	
	    <h3>
          <?php
             if(isset($error))
             { 
                 echo $error;
             }
          ?>
        
        
        </h3>
		
		   <h2>
          <?php
             if(isset($Success))
             { 
                 echo $Success;
             }
          ?>
        
        
        </h2>
		
		<div>
                <label for="">First Name:</label>
                <input type="text" placeholder="Enter First Name " name="firstname" />
        </div><br>
		
		<div>
                <label for="">Last Name:</label>
                <input type="text" placeholder="Enter Last Name " name="lastname" />
        </div><br>
		
		
		<div>
                <label for=""> Email:</label>
                <input type="text" placeholder="@gmail.com" name="email" />
        </div><br>
		
		<div>
                <label for="">Phone:</label>
                <input type="text" placeholder="Phone " name="phone" />
        </div><br>
		
		<div>
                <label for="">Gender:</label>
               <input type="radio" name="gender" value="male"/>Male 
               <input type="radio" name="gender" value="female"/>Female
        </div><br>
		 <div>
			<label>Date of birth</label>
			<input type="datetime" id="birthdaytime" name="b_date"/>
         </div><br>
		 <div>
                <label for="">Password:</label>
                <input type="password" placeholder="Password " name="password" />
        </div><br>
		 <div>
                <label for="">Confirm Password:</label>
                <input type="password" placeholder="Confirm Password " name="confpassword" />
        </div><br>
		
     
      <input type="submit"  name="registration" value="Sign up"> 
	    <a class="button" href="Login.php">Login</a>
	  

    </form>
  </body>
</html>
