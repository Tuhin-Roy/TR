<!DOCTYPE html>
<html>
<?php

  if (isset($_POST['signin']))
  {
    $Email=$_POST["email"];
	$Password=$_POST["password"];
  
  if(!empty($Email) && !empty($Password))
	 {
        
    

     }
	  else{

        $error='please fillup the required field';
          }

  }	
	?>

<head>
	<title>Login</title>
</head>
<body>
<h2> Login Here</h2>
<form action="" method="POST">

<h3>
          <?php
             if(isset($error))
             { 
                 echo $error;
             }
          ?>
		  
		          
        </h3>

<label for="">Email</label>
 <input type="text" name ="email"/>
<br></br>

<label for="">Password</label>
 <input type="text" name ="password"/>
 
 <br></br>
 
   <input type="submit" name ="signin" value="Sign in"/>
   <a class="button" href="index.php">Sign up</a>
 </form>
 </body>
 </html>