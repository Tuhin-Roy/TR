<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<h2> Login Here</h2>
<form>
<label for="fname">User name</label>
 <input type="text" id="fname">
<br></br>

<label for="p">Password</label>
 <input type="text" id="p">
 
 <br></br>
 <input type="button"  value="Sign in">
   <a class="button" href="Nregistration.php">Sign up</a>
 </form>
 </body>
 </html>