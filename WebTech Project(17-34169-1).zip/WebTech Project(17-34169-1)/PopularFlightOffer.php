<html>

<?php

  if (isset($_POST['BookFlight']))
  {
    $Email=$_POST["email"];
	$Passport=$_POST["passport"];
	$Name=$_POST["name"];
  
  if(!empty($Email) && !empty($Passport)&& !empty($Name))
	 {
        
    

     }
	  else{

        $error='please fillup the required field';
          }

  }	
	?>
<head>
 
 <title>BookTicket</title>
 <meta charset="UTF-8">

</head>

<body>
<h1 >Book Your Flight Here</h1>
<div>
 <a href="Login.php">Logout</a>
 </div> <br>
 
 <section>
  <nav>
    <ul><form><br>
      <div>
      <input  type="search" placeholder="Search-Flight" >
      <button  type="submit">Search-Flight</button>
	  </div>
 	  </form>
      <li><a href="#">Profile</a></li>
      <li><a href="#">About Us</a></li>
      <li><a href="#">Contact Information</a></li>
	  <br>
	  
    </ul>
  </nav>
  
  
</section>

<form action="" method="POST">
<div>
 <label>Select your Airway</label>
   <select>
     
      <option>Bangladesh Biman</option>
      <option>Emirites</option>
      <option>Quatar Airways</option>
      <option>London Airways</option>
      <option>Novo Air</option>
    </select>
</div> <br>

 <h3>
          <?php
             if(isset($error))
             { 
                 echo $error;
             }
          ?>
        
        
        </h3>
<div>
  <label>Name</label>
  <input type="text"name= "name"/>  
</div><br>
<div>
  <label>Email</label>
  <input type="text"name= "email"/>  
</div><br>
<div>
  <label>Passport No</label>
  <input type="text"name= "passport"/>  
</div><br>
<div>
  <input type="submit"name= "BookFlight"value="Book Flight"/>   
</div>



</form>









</body>














</html>