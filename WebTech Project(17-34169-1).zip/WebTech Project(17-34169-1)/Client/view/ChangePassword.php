<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
	</head>
	<body>
	<form method="post" action="rechangepassword.php">
		<div>
		<form method="post">
				
					

							<ul>
								<li><a href="EditProfile.php"><h3>Edit Profile</h3></a></li>
								<li><a href="ChangePassword.php"><h3>Change Password</h3></a></li>
								<li><a href="../control/logout.php"><h3>Logout</h3></a></li>
							</ul>
						
						   <center>
							
										<td>Current Password:</td>
										<td><input type ="text" name = "pass" method ="post"></td>
										<td></td>
									<br><br>
										<td>New Password:</td>
										<td><input type ="password" name ="cpass" method =""></td>
										<td></td>
									
									<br><br>
										<td>Re-type New Password:</td>
										<td><input type="password" name="rpass" /></td>
										<td></td>
									
									<br><br>
									
											<td></td>
											<td><input type ="submit" value ="Submit" name="submit"></td>
											<td></td>
								<br><br><br>
					
					<center>
					
		
	<form>	
		</div>
	</body>
</html>