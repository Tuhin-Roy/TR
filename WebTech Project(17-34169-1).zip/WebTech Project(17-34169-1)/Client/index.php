<?php
session_start();
?>

<html>
<head></head>

<body>

<center>
<form method="post" action="control/loginCheck.php">
	
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input type="text" name="id"><br/>                               
					Password<br/>
					<input type="password" name="password">
					<br><br>
					<input type="submit" value="Login" name="submit">
					<a href="view/registration.php">Register</a>
					<p>If you are not registerd then please Register First</p>
					<br>
				
</form>
</center>
</body>
</html>