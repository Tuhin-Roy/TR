<html>
<head>
 
 <title> Client Home</title>

</head>

<body>
<h1 > welcome to ...... Airway's</h1>
<div>
 <a href="Login.php">Logout</a>
 </div> <br>
 <section>
  <nav>
    <ul><form><br>
      <div>
      <input  type="search" placeholder="Search-Flight" >
      <button  type="submit">Search-Flight</button>
	  </div>
 	  </form>
      <a href="Profile.php"><input type="button" value="Profile"></a>
	  <li><a href="PopularFlightOffer.php">Popular Flight and Offer</a></li>
      <li><a href="#">About Us</a></li>
      <li><a href="#">Contact Information</a></li>
	  <br>
	  
    </ul>
  </nav>
  
  <article>
    <h1>Airway</h1>
    <p>Airway is ........................................</p>
    
  </article>
</section>









</body>














</html>